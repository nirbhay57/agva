#include "clickable_widget.h"
#include<QMessageBox>

clickable_widget::clickable_widget( QWidget *parent): QWidget(parent)
{

}
void clickable_widget::mousePressEvent(QMouseEvent* event){
	std::string str9 = "clicked widget";
	QString qstr = QString::fromStdString(str9);


	QMessageBox::about(this,"",qstr);


}
