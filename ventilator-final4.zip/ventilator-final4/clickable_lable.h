#ifndef CLICKABLE_LABLE_H
#define CLICKABLE_LABLE_H
#include<QLabel>


class clickable_lable : public QLabel
{
public:
	clickable_lable();

};

#endif // CLICKABLE_LABLE_H
