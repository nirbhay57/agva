#ifndef CLICKABLE_WIDGET_H
#define CLICKABLE_WIDGET_H
#include<QWidget>

class clickable_widget : public QWidget
{
public:
	clickable_widget( QWidget *parent=0);
	void mousePressEvent(QMouseEvent* event) override;
};

#endif // CLICKABLE_WIDGET_H
