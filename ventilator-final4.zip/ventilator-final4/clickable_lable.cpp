#include "clickable_lable.h"

clickable_lable::clickable_lable()
{

}
