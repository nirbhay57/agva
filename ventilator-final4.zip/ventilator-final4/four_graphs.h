#ifndef FOUR_GRAPHS_H
#define FOUR_GRAPHS_H


class four_graphs
{
public:
	four_graphs();
};

#endif // FOUR_GRAPHS_H
