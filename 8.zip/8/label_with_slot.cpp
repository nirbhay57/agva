#include "label_with_slot.h"

label_with_slot::label_with_slot()
{

}
