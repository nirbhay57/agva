    1  sudo i-
    2  sudo os-prober
    3  sudo -i
    4  exit
    5  sudo -i
    6  g++
    7  sudo -i
    8  exit
    9  g++
   10  sudo -i
   11  exit
   12  free -h
   13  g++
   14  g++ -v
   15  pwd
   16  exit
   17  sudo -i
   18  exit
   19  sudo -i
   20  screen
   21  sudo apt install screen
   22  screen
   23  synaptic
   24  ip addr show
   25  git clone -b vishal https://github.com/agvahealthcare/venti_qt.git
   26  sudo apt install git
   27  git clone -b vishal https://github.com/agvahealthcare/venti_qt.git
   28  swapon
   29  free -h
   30  swapon
   31  sudo swapon --show
   32  sudo apt get update
   33  sudo apt-get update
   34  exit
   35  vi a.cpp
   36  sudo -i
   37  vim
   38  grep -rnw  -e 'GraphicsLayoutFive'
   39  sudo snap install vlc
   40  sudo apt update
   41  sudo apt upgrade
   42  sudo apt install vlc
   43  sudo -i
   44  grep -rnw -e 'QtCharts'
   45  grep -rnw -e 'layout1'
   46  grep -rnw -e 'layout2'
   47  grep -rnw -e 'graphicsviewdialog.ui'
   48  grep -rnw -e 'graphicsviewdialog'
   49  grep -rnw -e 'stackedWidget'
   50  sudo apt install wine
   51  pwd
   52  ls
   53  cd CPP_prac
   54  ls
   55  vi delay.cpp
   56  g++ delay.cpp -std=c++11
   57  vi delay.cpp
   58  g++ delay.cpp -std=c++11
   59  ./a.out
   60  vi delay.cpp
   61  g++ delay.cpp -std=c++11
   62  ./a.out
   63  vi delay.cpp
   64  g++ delay.cpp -std=c++11
   65  ./a.out
   66  vi delay.cpp
   67  g++ delay.cpp -std=c++11
   68  ./a.out
   69  vi delay.cpp
   70  g++ delay.cpp -std=c++11
   71  ./a.out
   72  vi delay.cpp
   73  git clone https://github.com/ageitgey/face_recognition.git
   74  sudo snap install arduino
   75  sudo -i
   76  sudo -i
   77  ls
   78  sudo mv arduino-nightly /opt
   79  cd /opt
   80  ls
   81  cd arduino-nightly
   82  ls
   83  chmod +x install.sh
   84  ./install.sh
   85  sudo -i
   86  cd /dev
   87  ls
   88  cd ttyACM0
   89  vi ttyACM0
   90  cat ttyACM0
   91  cat tty9
   92  ls
   93  cheese
   94  sudo apt install cheese
   95  cheese
   96  pwd
   97  ls
   98  cd CPP_prac
   99  sudo -i
  100  ls
  101  vi mainwindow.cpp
  102  vi mainwindow.cpp
  103  sudo apt-get install alarm-clock
  104  sudo apt-get install espeak
  105  espeak “Some text or sentence. For example, wake up, or anything you want.”
  106  espeak “Some text ”
  107  espeak -f /home/nkp/Desktop/speak_alarm.txt
  108  espeak -f /home/nkp/Desktop/send-mail.txt
  109  espeak -f /home/nkp/Desktop/silence_please.txt
  110  at 08:00 ls
  111  sudo apt install at
  112  at 08:00 ls
  113  at 08:00 ls-l
  114  at now +1 minutes ls-l
  115  at now +1 minutes ls
  116  at now +1 minutes 
  117  at now +1 minutes cheese
  118  at cheese now +1 minutes 
  119  at now + 55 minutes
  120  at now + 55 minute
  121  espeak -f /home/nkp/Desktop/silence_please.txt
  122  at now +5 minutes
  123  at now +1 minutes
  124  atq
  125  espeak -f /home/nkp/Desktop/silence_please.txt
  126  exit
  127  cd CPP_prac
  128  vi test.cpp
  129  vi vimrc
  130  vi ~/.vimrc
  131  sudo -i
  132  exit
  133  espeak -f /home/nkp/Desktop/silence_please.txt
  134  qt
  135  google-chrome
  136  at 10:00 am
  137  espeak -f /home/nkp/Desktop/silence_please.txt
  138  google-chrome
  139  espeak -f /home/nkp/Desktop/silence_please.txt
  140  grep -R "dahina"*
  141  sudo apt install recordmydesktop
  142  recordmydesktop --on-the-fly-encoding
  143  which recordmydesktop
  144  sudo apt-get update
  145  sudo apt-get upgrade
  146  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  147  sudo apt install libqt5gui5-gles
  148  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  149  sudo apt install libqt5gui5
  150  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  151  sudo apt install libqt5core5a libqt5gui5  libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  152  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  153  sudo apt install libqt5gui5-gles
  154  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  155  sudo apt install libqt5gui5-gles
  156  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  157  sudo apt install libqt5core5a  libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  158  python3 a.py
  159  vi a.py
  160  python3 a.py
  161  espeak -f /home/nkp/Desktop/silence_please.txt
  162  espeak -f /home/nkp/Desktop/silence_please.t
  163  espeak -f /home/nkp/Desktop/silence_please.txt
  164  chmod +x 
  165  ls
  166  chmod +x  genymotion-3.2.1-linux_x64.bin
  167  sudo -i
  168  cheese
  169  vi a.cpp
  170  pwd
  171  ls
  172  cat a.cpp
  173  cat .a.cpp.swp
  174  ls
  175  mv  cat .a.cpp.swp
  176  cheese
  177  vi a.py
  178  python3 a.py
  179  vi a.py
  180  vi a.cpp
  181  vi. a.cpp.swp
  182  vi .a.cpp.swp
  183  mv .a.cpp.swp
  184  rd .a.cpp.swp
  185  rem .a.cpp.swp
  186  delete .a.cpp.swp
  187  rm .a.cpp.swp
  188  vi a.cpp
  189  g++ a.cpp -std=c++11
  190  vi a.cpp
  191  g++ a.cpp -std=c++11
  192  ./a.out
  193  vi a.cpp
  194  g++ a.cpp -std=c++11
  195  vi a.cpp
  196  g++ a.cpp -std=c++11
  197  ./a.out
  198  vi a.cpp
  199  g++ a.cpp -std=c++11
  200  ./a.out
  201  vi a.cpp
  202  g++ a.cpp -std=c++11
  203  ./a.out
  204  vi a.cpp
  205  g++ a.cpp -std=c++11
  206  ./a.out
  207  vi a.cpp
  208  g++ a.cpp -std=c++11
  209  vi a.cpp
  210  g++ a.cpp -std=c++11
  211  ./a.out
  212  vi a.cpp
  213  g++ a.cpp -std=c++11
  214  ./a.out
  215  vi a.cpp
  216  rm .a.cpp.swp
  217  vi a.cpp
  218  g++ a.cpp -std=c++11
  219  ./a.out
  220  vi a.cpp
  221  g++ a.cpp -std=c++11
  222  ./a.out
  223  vi a.cpp
  224  g++ a.cpp -std=c++11
  225  ./a.out
  226  vi a.cpp
  227  g++ a.cpp -std=c++11
  228  ./a.out
  229  vi a.cpp
  230  g++ a.cpp -std=c++11
  231  ./a.out
  232  vi a.cpp
  233  vi oo.cpp
  234  unlink oo.cpp
  235  vi oo.cpp
  236  sudo -i
  237  vi a.cpp
  238  g++ a.cpp -std=c++11
  239  vi a.cpp
  240  g++ a.cpp -std=c++11
  241  vi a.cpp
  242  espeak -f /home/nkp/Desktop/silence_please.txt
  243  ls
  244  vi a.cpp
  245  g++ a.cpp -std=c++11
  246  vi a.cpp
  247  g++ a.cpp -std=c++11
  248  vi a.cpp
  249  g++ a.cpp -std=c++11
  250  vi a.cpp
  251  g++ a.cpp -std=c++11
  252  vi a.cpp
  253  g++ a.cpp -std=c++11
  254  vi a.cpp
  255  ls
  256  vi a.cpp
  257  g++ a.cpp -std=c++11
  258  vi a.cpp
  259  g++ a.cpp -std=c++11
  260  vi a.cpp
  261  g++ a.cpp -std=c++11
  262  vi a.cpp
  263  g++ a.cpp -std=c++11
  264  vi a.cpp
  265  g++ a.cpp -std=c++11
  266  vi a.cpp
  267  g++ a.cpp -std=c++11
  268  vi a.cpp
  269  g++ a.cpp -std=c++11
  270  vi a.cpp
  271  g++ a.cpp -std=c++11
  272  vi a.cpp
  273  g++ a.cpp -std=c++11
  274  vi a.cpp
  275  g++ a.cpp -std=c++11
  276  ./a.out
  277  vi a.cpp
  278  g++ a.cpp -std=c++11
  279  ./a.out
  280  vi a.cpp
  281  g++ a.cpp -std=c++11
  282  ./a.out
  283  vi a.cpp
  284  g++ a.cpp -std=c++11
  285  ./a.out
  286  vi a.cpp
  287  g++ a.cpp -std=c++11
  288  ./a.out
  289  vi a.cpp
  290  g++ a.cpp -std=c++11
  291  ./a.out
  292  vi a.cpp
  293  g++ a.cpp -std=c++11
  294  ./a.out
  295  vi a.cpp
  296  g++ a.cpp -std=c++11
  297  ./a.out
  298  vi a.cpp
  299  g++ a.cpp -std=c++11
  300  ./a.out
  301  vi a.cpp
  302  g++ a.cpp -std=c++11
  303  ./a.out
  304  vi a.cpp
  305  ps -aux
  306  ps -aux | more
  307  pgrep 818Loop_Graph2
  308  kill 25687
  309  pgrep 818Loop_Graph2
  310  kill 27446
  311  cheese
  312  vi a.cpp
  313  g++ a.cpp -std=c++11
  314  vi a.cpp
  315  g++ a.cpp -std=c++11
  316  ./a.out
  317  vi a.cpp
  318  cheese
  319  pgrep 818Loop_Graph2
  320  ps -aux
  321  pgrep 819Loop_Graph2
  322  sudo -i
  323  pgrep 819LG_NoErrorWarnings
  324  pgrep 819LG_NoErrorWarning
  325  pgrep 819LG_NoErrorWarnings
  326  kill 819LG_NoErrorWarnings
  327  pgrep 819LG_NoErrorWarnings
  328  cheese
  329  vi a.cpp
  330  cp a.cpp b.cpp
  331  vi b.cpp
  332  g++ b.cpp -std=c++11
  333  ./a.out
  334  vi b.cpp
  335  g++ b.cpp -std=c++11
  336  ./a.out
  337  vi b.cpp
  338  g++ b.cpp -std=c++11
  339  ./a.out
  340  vi b.cpp
  341  g++ b.cpp -std=c++11
  342  ./a.out
  343  vi b.cpp
  344  g++ b.cpp -std=c++11
  345  ./a.out
  346  vi b.cpp
  347  g++ b.cpp -std=c++11
  348  ./a.out
  349  vi b.cpp
  350  g++ b.cpp -std=c++11
  351  ./a.out
  352  vi b.cpp
  353  g++ b.cpp -std=c++11
  354  ./a.out
  355  vi b.cpp
  356  cheese
  357  sudo snap install authy
  358  authy
  359  sudo snap remove authy
  360  vi b.cpp
  361  g++ b.cpp -std=c++11
  362  vi b.cpp
  363  g++ b.cpp -std=c++11
  364  vi b.cpp
  365  g++ b.cpp -std=c++11
  366  vi b.cpp
  367  g++ b.cpp -std=c++11
  368  cheese
  369  sudo apt update
  370  sudo apt install apt-transport-https ca-certificates curl gnupg-agent software-properties-common 
  371  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
  372  sudo -i
  373  vi b.cpp
  374  g++ b.cpp -std=c++11
  375  vi b.cpp
  376  g++ b.cpp -std=c++11
  377  vi b.cpp
  378  g++ b.cpp -std=c++11
  379  vi b.cpp
  380  g++ b.cpp -std=c++11
  381  ./a.out
  382  vi b.cpp
  383  g++ b.cpp -std=c++11
  384  ./a.out
  385  vi b.cpp
  386  g++ b.cpp -std=c++11
  387  vi b.cpp
  388  g++ b.cpp -std=c++11
  389  vi b.cpp
  390  g++ b.cpp -std=c++11
  391  ./a.out
  392  vi b.cpp
  393  cheese
  394  cd /usr/share/arduino
  395  cd /user/share/arduino
  396  cd /usr
  397  pwd
  398  ls
  399  cd share
  400  ls
  401  cd /home/nkp
  402  pwd
  403  ls
  404  cd Arduino
  405  ls
  406  cd libraries
  407  ls
  408  vi a.cpp
  409  vi a1.cpp
  410  g++ a1.cpp -std=c++11
  411  vi a1.cpp
  412  g++ a1.cpp -std=c++11
  413  vi a1.cpp
  414  g++ a1.cpp -std=c++11
  415  ./a.out
  416  vi a1.cpp
  417  g++ a1.cpp -std=c++11
  418  ./a.out
  419  vi a1.cpp
  420  g++ a1.cpp -std=c++11
  421  ./a.out
  422  vi a1.cpp
  423  g++ a1.cpp -std=c++11
  424  ./a.out
  425  vi a1.cpp
  426  g++ a1.cpp -std=c++11
  427  vi a1.cpp
  428  g++ a1.cpp -std=c++11
  429  ./a.out
  430  vi a1.cpp
  431  g++ a1.cpp -std=c++11
  432  vi a1.cpp
  433  g++ a1.cpp -std=c++11
  434  vi a1.cpp
  435  g++ a1.cpp -std=c++11
  436  vi a1.cpp
  437  g++ a1.cpp -std=c++11
  438  vi a1.cpp
  439  g++ a1.cpp -std=c++11
  440  ./a.out
  441  vi a1.cpp
  442  g++ a1.cpp -std=c++11
  443  ./a.out
  444  vi a1.cpp
  445  cp a1.cpp  a2.cpp
  446  vi a2.cpp
  447  g++ a2.cpp -std=c++11
  448  vi a2.cpp
  449  g++ a2.cpp -std=c++11
  450  vi a2.cpp
  451  g++ a2.cpp -std=c++11
  452  vi a2.cpp
  453  g++ a2.cpp -std=c++11
  454  ./a.out
  455  vi a2.cpp
  456  g++ a2.cpp -std=c++11
  457  ./a.out
  458  vi a2.cpp
  459  cp a2.cpp a3.cpp
  460  vi a3.cpp
  461  g++ a3.cpp -std=c++11
  462  ./a.out
  463  vi a3.cpp
  464  cp a3.cpp a4.cpp
  465  vi a4.cpp
  466  g++ a4.cpp -std=c++11
  467  vi a4.cpp
  468  g++ a4.cpp -std=c++11
  469  vi a4.cpp
  470  g++ a4.cpp -std=c++11
  471  vi a4.cpp
  472  g++ a4.cpp -std=c++11
  473  vi a4.cpp
  474  g++ a4.cpp -std=c++11
  475  vi a4.cpp
  476  g++ a4.cpp -std=c++11
  477  ./a.out
  478  vi a4.cpp
  479  g++ a4.cpp -std=c++11
  480  ./a.out
  481  vi a4.cpp
  482  g++ a4.cpp -std=c++11
  483  vi a4.cpp
  484  g++ a4.cpp -std=c++11
  485  ./a.out
  486  vi a4.cpp
  487  g++ a4.cpp -std=c++11
  488  vi a4.cpp
  489  vi a3.cpp
  490  cp a3.cpp a31.cpp
  491  vi a31.cpp
  492  g++ a31.cpp -std=c++11
  493  ./a.out
  494  vi a31.cpp
  495  g++ a31.cpp -std=c++11
  496  ./a.out
  497  vi a31.cpp
  498  g++ a31.cpp -std=c++11
  499  ./a.out
  500  vi a31.cpp
  501  vi test.cpp
  502  g++ test.cpp -std=c++11
  503  vi test.cpp
  504  g++ test.cpp -std=c++11
  505  vi test.cpp
  506  g++ test.cpp -std=c++11
  507  vi test.cpp
  508  g++ test.cpp -std=c++11
  509  vi test.cpp
  510  g++ test.cpp -std=c++11
  511  ./a.out
  512  vi test.cpp
  513  g++ test.cpp -std=c++11
  514  ./a.out
  515  vi test.cpp
  516  cp test.cpp test1.cpp
  517  vi test1.cpp
  518  g++ test1.cpp -std=c++11
  519  ./a.out
  520  vi test1.cpp
  521  g++ test1.cpp -std=c++11
  522  ./a.out
  523  vi test1.cpp
  524  g++ test1.cpp -std=c++11
  525  ./a.out
  526  vi test1.cpp
  527  g++ test1.cpp -std=c++11
  528  ./a.out
  529  vi test1.cpp
  530  g++ test1.cpp -std=c++11
  531  ./a.out
  532  vi test1.cpp
  533  g++ test1.cpp -std=c++11
  534  ./a.out
  535  cp test1.cpp test2.cpp
  536  vi test2.cpp
  537  g++ test2.cpp -std=c++11
  538  vi test2.cpp
  539  g++ test2.cpp -std=c++11
  540  vi test2.cpp
  541  g++ test2.cpp -std=c++11
  542  vi test2.cpp
  543  g++ test2.cpp -std=c++11
  544  vi test2.cpp
  545  g++ test2.cpp -std=c++11
  546  vi test2.cpp
  547  g++ test2.cpp -std=c++11
  548  ./a.out
  549  vi test2.cpp
  550  g++ test2.cpp -std=c++11
  551  ./a.out
  552  vi test2.cpp
  553  pwd
  554  ls
  555  vi test2.cpp
  556  vi test1.cpp
  557  git init
  558  git status
  559  git add .
  560  git status
  561  git init
  562  git status
  563  git add .
  564  git status
  565  git commit -m "jajajaj"
  566  git checkout -b nkp_repo
  567  git checkout main
  568  vi test2.cpp
  569  ls *.cpp
  570  ls *.swp
  571  vi test1.cpp
  572  mv .test1.cpp.swp .test1.cpp.swp1
  573  vi test1.cpp
  574  g++ test1.cpp -std=c++11
  575  ./a.out
  576  vi test1.cpp
  577  cp test1.cpp test11.cpp
  578  vi test11.cpp
  579  g++ test11.cpp -std=c++11
  580  ./a.out
  581  vi test11.cpp
  582  vi test2.cpp
  583  g++ test2.cpp -std=c++11
  584  vi test2.cpp
  585  g++ test2.cpp -std=c++11
  586  ./a.out
  587  vi test2.cpp
  588  g++ test2.cpp -std=c++11
  589  cp test2.cpp test21.cpp
  590  vi test21.cpp
  591  g++ test2.cpp -std=c++11
  592  ./a.out
  593  ls
  594  g++ test2.cpp -std=c++11
  595  vi test2.cpp
  596  g++ test21.cpp -std=c++11
  597  ./a.out
  598  g++ test2.cpp -std=c++11
  599  ./a.out
  600  g++ test2.cpp -std=c++11
  601  pwd
  602  g++ test2.cpp -std=c++11
  603  g++ test21.cpp -std=c++11
  604  ./a.out
  605  g++ test21.cpp -std=c++11
  606  ./a.out
  607  vi test21.cpp 
  608  g++ test21.cpp -std=c++11
  609  ./a.out
  610  vi test21.cpp 
  611  g++ test21.cpp -std=c++11
  612  ./a.out
  613  vi test21.cpp 
  614  g++ test21.cpp -std=c++11
  615  ./a.out
  616  vi test21.cpp 
  617  g++ test21.cpp -std=c++11
  618  ./a.out
  619  vi test21.cpp 
  620  g++ test21.cpp -std=c++11
  621  ./a.out
  622  vi test21.cpp 
  623  g++ test21.cpp -std=c++11
  624  ./a.out
  625  vi test21.cpp 
  626  g++ test21.cpp -std=c++11
  627  ./a.out
  628  vi test21.cpp 
  629  g++ test21.cpp -std=c++11
  630  ./a.out
  631  vi test21.cpp 
  632  git status
  633  git add .
  634  git status
  635  git commit -m "will see it"
  636  git config --global user.email nirbhay57@gmail.com
  637  git config --global user.name nirbhay57
  638  git remote add origin https://github.com/nirbhay57/agva.git
  639  git push -u origin main
  640  git remote set-url origin https://github.com/nirbhay57/agva.git
  641  git push -u origin main
  642  git remote -v
  643  git push -u origin main -f
  644  git push -u origin main --force
  645  git branch -M main
  646  git remote add origin https://github.com/nirbhay57/agva.git
  647  git branch -M main
  648  git init 
  649  /home/nkp/realtime_qlabel/8/.git/
  650  rd /home/nkp/realtime_qlabel/8/.git/
  651  rm -r  /home/nkp/realtime_qlabel/8/.git/
  652  rm -rf  /home/nkp/realtime_qlabel/8/.git/
  653  rm -r  /home/nkp/realtime_qlabel/8/.git/
  654  git init
  655  git commit -m "first commit"
  656  git add .
  657  git status
  658  git commit -m "first commit"
  659  git branch -M main
  660  git remote add origin https://github.com/nirbhay57/agva.git
  661  git push -u origin main
  662  curl -u "nirbhay57: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" https://github.com/nirbhay57/agva.git
  663  git push -u origin main
  664  git config --global user.email nirbhay57@gmail.com
  665  git config --global user.name nirbhay57
  666  git config --global user.email nirbhay57@gmail.com
  667  git config -l
  668  git commit -m "first commit"
  669  git add .
  670  git commit -m "first commit"
  671  git status
  672  git add .
  673  git status
  674  git commit -m "first commit"
  675  git branch -M main
  676  git remote add origin https://github.com/nirbhay57/agva.git
  677  git push -u origin main
  678  history
  679  history >> hist1.cpp
