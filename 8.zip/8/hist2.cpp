nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git init
Initialized empty Git repository in /home/nkp/realtime_qlabel/8/.git/
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git commit -m "first commit"
On branch master

Initial commit

Untracked files:
  (use "git add <file>..." to include in what will be committed)
	8.pro
	8.pro.user
	SampleECG.txt
	SampleECG_converted.txt
	arduino.txt
	bell.cpp
	bell.h
	bell.ui
	btn.cpp
	btn.h
	chargograph.cpp
	chargograph.h
	chargograph.ui
	clickable_lable.cpp
	clickable_lable.h
	clickable_widget.cpp
	clickable_widget.h
	custom_pushbutton.cpp
	custom_pushbutton.h
	ecg.cpp
	ecg.h
	ecg.txt
	ecg1.txt
	ecg2.txt
	ecg3.txt
	ecg_sa.ui
	four_graphs.cpp
	four_graphs.h
	fourgraphs.cpp
	fourgraphs.h
	fourgraphs.ui
	img/
	itemsetvalue.cpp
	itemsetvalue.h
	itemsetvalue1.cpp
	itemsetvalue1.h
	label_with_slot.cpp
	label_with_slot.h
	main.cpp
	mainwindow.cpp
	mainwindow.h
	mainwindow.ui
	meterdata.h
	naya_form.cpp
	naya_form.h
	naya_form.ui
	readingdata.h
	risors.qrc
	setparameter.cpp
	setparameter.h
	setparameter.ui
	setparameter1.cpp
	setparameter1.h
	setparameter1.ui
	stprmtr.cpp
	stprmtr.h
	stprmtr.ui
	ui_ecg.h
	unitchart.cpp
	unitchart.h
	unitchart.ui
	volumechart.cpp
	volumechart.h
	volumechart.ui

nothing added to commit but untracked files present (use "git add" to track)
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git add .
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git status
On branch master

No commits yet

Changes to be committed:
  (use "git rm --cached <file>..." to unstage)
	new file:   8.pro
	new file:   8.pro.user
	new file:   SampleECG.txt
	new file:   SampleECG_converted.txt
	new file:   arduino.txt
	new file:   bell.cpp
	new file:   bell.h
	new file:   bell.ui
	new file:   btn.cpp
	new file:   btn.h
	new file:   chargograph.cpp
	new file:   chargograph.h
	new file:   chargograph.ui
	new file:   clickable_lable.cpp
	new file:   clickable_lable.h
	new file:   clickable_widget.cpp
	new file:   clickable_widget.h
	new file:   custom_pushbutton.cpp
	new file:   custom_pushbutton.h
	new file:   ecg.cpp
	new file:   ecg.h
	new file:   ecg.txt
	new file:   ecg1.txt
	new file:   ecg2.txt
	new file:   ecg3.txt
	new file:   ecg_sa.ui
	new file:   four_graphs.cpp
	new file:   four_graphs.h
	new file:   fourgraphs.cpp
	new file:   fourgraphs.h
	new file:   fourgraphs.ui
	new file:   img/Group 431.svg
	new file:   img/alarm on.png
	new file:   img/alarm on.svg
	new file:   img/alarm1.png
	new file:   img/alarm2.svg
	new file:   img/betri_soya.png
	new file:   img/ic_battery.png
	new file:   img/ic_close.png
	new file:   img/ic_down_arrow.png
	new file:   img/ic_dropdown.png
	new file:   img/ic_female.png
	new file:   img/ic_female_default.png
	new file:   img/ic_female_select.png
	new file:   img/ic_greenPlug.png
	new file:   img/ic_lungs.png
	new file:   img/ic_male.png
	new file:   img/ic_male_default.png
	new file:   img/ic_standby.jpeg
	new file:   img/ic_standby.jpg
	new file:   img/ic_standby.png
	new file:   img/ic_up_arrow.png
	new file:   img/layout_1.png
	new file:   img/layout_2.png
	new file:   img/layout_3.png
	new file:   img/layout_4.png
	new file:   img/layout_5.png
	new file:   img/sbi1.jpg
	new file:   img/sbi1.png
	new file:   img/sbi2.svg
	new file:   img/sbi2_256.png
	new file:   img/standby_green.png
	new file:   itemsetvalue.cpp
	new file:   itemsetvalue.h
	new file:   itemsetvalue1.cpp
	new file:   itemsetvalue1.h
	new file:   label_with_slot.cpp
	new file:   label_with_slot.h
	new file:   main.cpp
	new file:   mainwindow.cpp
	new file:   mainwindow.h
	new file:   mainwindow.ui
	new file:   meterdata.h
	new file:   naya_form.cpp
	new file:   naya_form.h
	new file:   naya_form.ui
	new file:   readingdata.h
	new file:   risors.qrc
	new file:   setparameter.cpp
	new file:   setparameter.h
	new file:   setparameter.ui
	new file:   setparameter1.cpp
	new file:   setparameter1.h
	new file:   setparameter1.ui
	new file:   stprmtr.cpp
	new file:   stprmtr.h
	new file:   stprmtr.ui
	new file:   ui_ecg.h
	new file:   unitchart.cpp
	new file:   unitchart.h
	new file:   unitchart.ui
	new file:   volumechart.cpp
	new file:   volumechart.h
	new file:   volumechart.ui

nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git commit -m "first commit"
[master (root-commit) 343993a] first commit
 94 files changed, 874378 insertions(+)
 create mode 100644 8.pro
 create mode 100644 8.pro.user
 create mode 100644 SampleECG.txt
 create mode 100644 SampleECG_converted.txt
 create mode 100644 arduino.txt
 create mode 100644 bell.cpp
 create mode 100644 bell.h
 create mode 100644 bell.ui
 create mode 100644 btn.cpp
 create mode 100644 btn.h
 create mode 100644 chargograph.cpp
 create mode 100644 chargograph.h
 create mode 100644 chargograph.ui
 create mode 100644 clickable_lable.cpp
 create mode 100644 clickable_lable.h
 create mode 100644 clickable_widget.cpp
 create mode 100644 clickable_widget.h
 create mode 100644 custom_pushbutton.cpp
 create mode 100644 custom_pushbutton.h
 create mode 100644 ecg.cpp
 create mode 100644 ecg.h
 create mode 100644 ecg.txt
 create mode 100644 ecg1.txt
 create mode 100644 ecg2.txt
 create mode 100644 ecg3.txt
 create mode 100644 ecg_sa.ui
 create mode 100644 four_graphs.cpp
 create mode 100644 four_graphs.h
 create mode 100644 fourgraphs.cpp
 create mode 100644 fourgraphs.h
 create mode 100644 fourgraphs.ui
 create mode 100644 img/Group 431.svg
 create mode 100644 img/alarm on.png
 create mode 100644 img/alarm on.svg
 create mode 100644 img/alarm1.png
 create mode 100644 img/alarm2.svg
 create mode 100644 img/betri_soya.png
 create mode 100644 img/ic_battery.png
 create mode 100644 img/ic_close.png
 create mode 100644 img/ic_down_arrow.png
 create mode 100644 img/ic_dropdown.png
 create mode 100644 img/ic_female.png
 create mode 100644 img/ic_female_default.png
 create mode 100644 img/ic_female_select.png
 create mode 100644 img/ic_greenPlug.png
 create mode 100644 img/ic_lungs.png
 create mode 100644 img/ic_male.png
 create mode 100644 img/ic_male_default.png
 create mode 100644 img/ic_standby.jpeg
 create mode 100644 img/ic_standby.jpg
 create mode 100644 img/ic_standby.png
 create mode 100644 img/ic_up_arrow.png
 create mode 100644 img/layout_1.png
 create mode 100644 img/layout_2.png
 create mode 100644 img/layout_3.png
 create mode 100644 img/layout_4.png
 create mode 100644 img/layout_5.png
 create mode 100644 img/sbi1.jpg
 create mode 100644 img/sbi1.png
 create mode 100644 img/sbi2.svg
 create mode 100644 img/sbi2_256.png
 create mode 100644 img/standby_green.png
 create mode 100644 itemsetvalue.cpp
 create mode 100644 itemsetvalue.h
 create mode 100644 itemsetvalue1.cpp
 create mode 100644 itemsetvalue1.h
 create mode 100644 label_with_slot.cpp
 create mode 100644 label_with_slot.h
 create mode 100644 main.cpp
 create mode 100644 mainwindow.cpp
 create mode 100644 mainwindow.h
 create mode 100644 mainwindow.ui
 create mode 100644 meterdata.h
 create mode 100644 naya_form.cpp
 create mode 100644 naya_form.h
 create mode 100644 naya_form.ui
 create mode 100644 readingdata.h
 create mode 100644 risors.qrc
 create mode 100644 setparameter.cpp
 create mode 100644 setparameter.h
 create mode 100644 setparameter.ui
 create mode 100644 setparameter1.cpp
 create mode 100644 setparameter1.h
 create mode 100644 setparameter1.ui
 create mode 100644 stprmtr.cpp
 create mode 100644 stprmtr.h
 create mode 100644 stprmtr.ui
 create mode 100644 ui_ecg.h
 create mode 100644 unitchart.cpp
 create mode 100644 unitchart.h
 create mode 100644 unitchart.ui
 create mode 100644 volumechart.cpp
 create mode 100644 volumechart.h
 create mode 100644 volumechart.ui
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git branch -M main
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git remote add origin https://github.com/nirbhay57/agva.git
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay
Password for 'https://nirbhay@github.com': 
[1]+  Stopped                 git push -u origin main
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ ^C
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ ^C
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay57
Password for 'https://nirbhay57@github.com': 
remote: Support for password authentication was removed on August 13, 2021. Please use a personal access token instead.
remote: Please see https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/ for more information.
fatal: Authentication failed for 'https://github.com/nirbhay57/agva.git/'
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay57
Password for 'https://nirbhay57@github.com': 
remote: Support for password authentication was removed on August 13, 2021. Please use a personal access token instead.
remote: Please see https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/ for more information.
fatal: Authentication failed for 'https://github.com/nirbhay57/agva.git/'
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay57
Password for 'https://nirbhay57@github.com': 
remote: Support for password authentication was removed on August 13, 2021. Please use a personal access token instead.
remote: Please see https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/ for more information.
fatal: Authentication failed for 'https://github.com/nirbhay57/agva.git/'
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay57
Password for 'https://nirbhay57@github.com': 
remote: Support for password authentication was removed on August 13, 2021. Please use a personal access token instead.
remote: Please see https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/ for more information.
fatal: Authentication failed for 'https://github.com/nirbhay57/agva.git/'
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ curl -u "nirbhay57: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" https://github.com/nirbhay57/agva.git
<html>
<head><title>301 Moved Permanently</title></head>
<body>
<center><h1>301 Moved Permanently</h1></center>
<hr><center>nginx</center>
</body>
</html>
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay57
Password for 'https://nirbhay57@github.com': 
remote: Support for password authentication was removed on August 13, 2021. Please use a personal access token instead.
remote: Please see https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/ for monkpnnnkpnkpnkpnkpnknknknkpnkpnnkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git config --global user.email nirbhay57@gmail.com
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git config --global user.name nirbhay57
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git config --global user.email nirbhay57@gmail.com
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git config -l
user.email=nirbhay57@gmail.com
user.name=nirbhay57
core.repositoryformatversion=0
core.filemode=true
core.bare=false
core.logallrefupdates=true
remote.origin.url=https://github.com/nirbhay57/agva.git
remote.origin.fetch=+refs/heads/*:refs/remotes/origin/*
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git commit -m "first commit"
On branch main
nothing to commit, working tree clean
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git commit -m "first commit"
On branch main
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
	modified:   arduino.txt

no changes added to commit (use "git add" and/or "git commit -a")
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git add .
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git commit -m "first commit"
[main 988f7e2] first commit
 1 file changed, 1 insertion(+), 1 deletion(-)
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git status
On branch main
nothing to commit, working tree clean
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git status
On branch main
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
	modified:   arduino.txt

no changes added to commit (use "git add" and/or "git commit -a")
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git add .
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git status
On branch main
Changes to be committed:
  (use "git restore --staged <file>..." to unstage)
	modified:   arduino.txt

nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git commit -m "first commit"
[main 0bb8174] first commit
 1 file changed, 1 insertion(+), 1 deletion(-)
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git branch -M main
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git remote add origin https://github.com/nirbhay57/agva.git
fatal: remote origin already exists.
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ git push -u origin main
Username for 'https://github.com': nirbhay57
Password for 'https://nirbhay57@github.com': 
Enumerating objects: 101, done.
Counting objects: 100% (101/101), done.
Delta compression using up to 4 threads
Compressing objects: 100% (100/100), done.
Writing objects: 100% (101/101), 3.69 MiB | 2.59 MiB/s, done.
Total 101 (delta 15), reused 0 (delta 0)
remote: Resolving deltas: 100% (15/15), done.
To https://github.com/nirbhay57/agva.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ history
    1  sudo i-
    2  sudo os-prober
    3  sudo -i
    4  exit
    5  sudo -i
    6  g++
    7  sudo -i
    8  exit
    9  g++
   10  sudo -i
   11  exit
   12  free -h
   13  g++
   14  g++ -v
   15  pwd
   16  exit
   17  sudo -i
   18  exit
   19  sudo -i
   20  screen
   21  sudo apt install screen
   22  screen
   23  synaptic
   24  ip addr show
   25  git clone -b vishal https://github.com/agvahealthcare/venti_qt.git
   26  sudo apt install git
   27  git clone -b vishal https://github.com/agvahealthcare/venti_qt.git
   28  swapon
   29  free -h
   30  swapon
   31  sudo swapon --show
   32  sudo apt get update
   33  sudo apt-get update
   34  exit
   35  vi a.cpp
   36  sudo -i
   37  vim
   38  grep -rnw  -e 'GraphicsLayoutFive'
   39  sudo snap install vlc
   40  sudo apt update
   41  sudo apt upgrade
   42  sudo apt install vlc
   43  sudo -i
   44  grep -rnw -e 'QtCharts'
   45  grep -rnw -e 'layout1'
   46  grep -rnw -e 'layout2'
   47  grep -rnw -e 'graphicsviewdialog.ui'
   48  grep -rnw -e 'graphicsviewdialog'
   49  grep -rnw -e 'stackedWidget'
   50  sudo apt install wine
   51  pwd
   52  ls
   53  cd CPP_prac
   54  ls
   55  vi delay.cpp
   56  g++ delay.cpp -std=c++11
   57  vi delay.cpp
   58  g++ delay.cpp -std=c++11
   59  ./a.out
   60  vi delay.cpp
   61  g++ delay.cpp -std=c++11
   62  ./a.out
   63  vi delay.cpp
   64  g++ delay.cpp -std=c++11
   65  ./a.out
   66  vi delay.cpp
   67  g++ delay.cpp -std=c++11
   68  ./a.out
   69  vi delay.cpp
   70  g++ delay.cpp -std=c++11
   71  ./a.out
   72  vi delay.cpp
   73  git clone https://github.com/ageitgey/face_recognition.git
   74  sudo snap install arduino
   75  sudo -i
   76  sudo -i
   77  ls
   78  sudo mv arduino-nightly /opt
   79  cd /opt
   80  ls
   81  cd arduino-nightly
   82  ls
   83  chmod +x install.sh
   84  ./install.sh
   85  sudo -i
   86  cd /dev
   87  ls
   88  cd ttyACM0
   89  vi ttyACM0
   90  cat ttyACM0
   91  cat tty9
   92  ls
   93  cheese
   94  sudo apt install cheese
   95  cheese
   96  pwd
   97  ls
   98  cd CPP_prac
   99  sudo -i
  100  ls
  101  vi mainwindow.cpp
  102  vi mainwindow.cpp
  103  sudo apt-get install alarm-clock
  104  sudo apt-get install espeak
  105  espeak “Some text or sentence. For example, wake up, or anything you want.”
  106  espeak “Some text ”
  107  espeak -f /home/nkp/Desktop/speak_alarm.txt
  108  espeak -f /home/nkp/Desktop/send-mail.txt
  109  espeak -f /home/nkp/Desktop/silence_please.txt
  110  at 08:00 ls
  111  sudo apt install at
  112  at 08:00 ls
  113  at 08:00 ls-l
  114  at now +1 minutes ls-l
  115  at now +1 minutes ls
  116  at now +1 minutes 
  117  at now +1 minutes cheese
  118  at cheese now +1 minutes 
  119  at now + 55 minutes
  120  at now + 55 minute
  121  espeak -f /home/nkp/Desktop/silence_please.txt
  122  at now +5 minutes
  123  at now +1 minutes
  124  atq
  125  espeak -f /home/nkp/Desktop/silence_please.txt
  126  exit
  127  cd CPP_prac
  128  vi test.cpp
  129  vi vimrc
  130  vi ~/.vimrc
  131  sudo -i
  132  exit
  133  espeak -f /home/nkp/Desktop/silence_please.txt
  134  qt
  135  google-chrome
  136  at 10:00 am
  137  espeak -f /home/nkp/Desktop/silence_please.txt
  138  google-chrome
  139  espeak -f /home/nkp/Desktop/silence_please.txt
  140  grep -R "dahina"*
  141  sudo apt install recordmydesktop
  142  recordmydesktop --on-the-fly-encoding
  143  which recordmydesktop
  144  sudo apt-get update
  145  sudo apt-get upgrade
  146  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  147  sudo apt install libqt5gui5-gles
  148  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  149  sudo apt install libqt5gui5
  150  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  151  sudo apt install libqt5core5a libqt5gui5  libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  152  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  153  sudo apt install libqt5gui5-gles
  154  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  155  sudo apt install libqt5gui5-gles
  156  sudo apt install libqt5core5a libqt5gui5 libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  157  sudo apt install libqt5core5a  libqt5gui5-gles libqt5opengl5 libqt5printsupport5 libqt5widgets5 libqt5x11extras5 libsdl1.2debian python2.7-minimal
  158  python3 a.py
  159  vi a.py
  160  python3 a.py
  161  espeak -f /home/nkp/Desktop/silence_please.txt
  162  espeak -f /home/nkp/Desktop/silence_please.t
  163  espeak -f /home/nkp/Desktop/silence_please.txt
  164  chmod +x 
  165  ls
  166  chmod +x  genymotion-3.2.1-linux_x64.bin
  167  sudo -i
  168  cheese
  169  vi a.cpp
  170  pwd
  171  ls
  172  cat a.cpp
  173  cat .a.cpp.swp
  174  ls
  175  mv  cat .a.cpp.swp
  176  cheese
  177  vi a.py
  178  python3 a.py
  179  vi a.py
  180  vi a.cpp
  181  vi. a.cpp.swp
  182  vi .a.cpp.swp
  183  mv .a.cpp.swp
  184  rd .a.cpp.swp
  185  rem .a.cpp.swp
  186  delete .a.cpp.swp
  187  rm .a.cpp.swp
  188  vi a.cpp
  189  g++ a.cpp -std=c++11
  190  vi a.cpp
  191  g++ a.cpp -std=c++11
  192  ./a.out
  193  vi a.cpp
  194  g++ a.cpp -std=c++11
  195  vi a.cpp
  196  g++ a.cpp -std=c++11
  197  ./a.out
  198  vi a.cpp
  199  g++ a.cpp -std=c++11
  200  ./a.out
  201  vi a.cpp
  202  g++ a.cpp -std=c++11
  203  ./a.out
  204  vi a.cpp
  205  g++ a.cpp -std=c++11
  206  ./a.out
  207  vi a.cpp
  208  g++ a.cpp -std=c++11
  209  vi a.cpp
  210  g++ a.cpp -std=c++11
  211  ./a.out
  212  vi a.cpp
  213  g++ a.cpp -std=c++11
  214  ./a.out
  215  vi a.cpp
  216  rm .a.cpp.swp
  217  vi a.cpp
  218  g++ a.cpp -std=c++11
  219  ./a.out
  220  vi a.cpp
  221  g++ a.cpp -std=c++11
  222  ./a.out
  223  vi a.cpp
  224  g++ a.cpp -std=c++11
  225  ./a.out
  226  vi a.cpp
  227  g++ a.cpp -std=c++11
  228  ./a.out
  229  vi a.cpp
  230  g++ a.cpp -std=c++11
  231  ./a.out
  232  vi a.cpp
  233  vi oo.cpp
  234  unlink oo.cpp
  235  vi oo.cpp
  236  sudo -i
  237  vi a.cpp
  238  g++ a.cpp -std=c++11
  239  vi a.cpp
  240  g++ a.cpp -std=c++11
  241  vi a.cpp
  242  espeak -f /home/nkp/Desktop/silence_please.txt
  243  ls
  244  vi a.cpp
  245  g++ a.cpp -std=c++11
  246  vi a.cpp
  247  g++ a.cpp -std=c++11
  248  vi a.cpp
  249  g++ a.cpp -std=c++11
  250  vi a.cpp
  251  g++ a.cpp -std=c++11
  252  vi a.cpp
  253  g++ a.cpp -std=c++11
  254  vi a.cpp
  255  ls
  256  vi a.cpp
  257  g++ a.cpp -std=c++11
  258  vi a.cpp
  259  g++ a.cpp -std=c++11
  260  vi a.cpp
  261  g++ a.cpp -std=c++11
  262  vi a.cpp
  263  g++ a.cpp -std=c++11
  264  vi a.cpp
  265  g++ a.cpp -std=c++11
  266  vi a.cpp
  267  g++ a.cpp -std=c++11
  268  vi a.cpp
  269  g++ a.cpp -std=c++11
  270  vi a.cpp
  271  g++ a.cpp -std=c++11
  272  vi a.cpp
  273  g++ a.cpp -std=c++11
  274  vi a.cpp
  275  g++ a.cpp -std=c++11
  276  ./a.out
  277  vi a.cpp
  278  g++ a.cpp -std=c++11
  279  ./a.out
  280  vi a.cpp
  281  g++ a.cpp -std=c++11
  282  ./a.out
  283  vi a.cpp
  284  g++ a.cpp -std=c++11
  285  ./a.out
  286  vi a.cpp
  287  g++ a.cpp -std=c++11
  288  ./a.out
  289  vi a.cpp
  290  g++ a.cpp -std=c++11
  291  ./a.out
  292  vi a.cpp
  293  g++ a.cpp -std=c++11
  294  ./a.out
  295  vi a.cpp
  296  g++ a.cpp -std=c++11
  297  ./a.out
  298  vi a.cpp
  299  g++ a.cpp -std=c++11
  300  ./a.out
  301  vi a.cpp
  302  g++ a.cpp -std=c++11
  303  ./a.out
  304  vi a.cpp
  305  ps -aux
  306  ps -aux | more
  307  pgrep 818Loop_Graph2
  308  kill 25687
  309  pgrep 818Loop_Graph2
  310  kill 27446
  311  cheese
  312  vi a.cpp
  313  g++ a.cpp -std=c++11
  314  vi a.cpp
  315  g++ a.cpp -std=c++11
  316  ./a.out
  317  vi a.cpp
  318  cheese
  319  pgrep 818Loop_Graph2
  320  ps -aux
  321  pgrep 819Loop_Graph2
  322  sudo -i
  323  pgrep 819LG_NoErrorWarnings
  324  pgrep 819LG_NoErrorWarning
  325  pgrep 819LG_NoErrorWarnings
  326  kill 819LG_NoErrorWarnings
  327  pgrep 819LG_NoErrorWarnings
  328  cheese
  329  vi a.cpp
  330  cp a.cpp b.cpp
  331  vi b.cpp
  332  g++ b.cpp -std=c++11
  333  ./a.out
  334  vi b.cpp
  335  g++ b.cpp -std=c++11
  336  ./a.out
  337  vi b.cpp
  338  g++ b.cpp -std=c++11
  339  ./a.out
  340  vi b.cpp
  341  g++ b.cpp -std=c++11
  342  ./a.out
  343  vi b.cpp
  344  g++ b.cpp -std=c++11
  345  ./a.out
  346  vi b.cpp
  347  g++ b.cpp -std=c++11
  348  ./a.out
  349  vi b.cpp
  350  g++ b.cpp -std=c++11
  351  ./a.out
  352  vi b.cpp
  353  g++ b.cpp -std=c++11
  354  ./a.out
  355  vi b.cpp
  356  cheese
  357  sudo snap install authy
  358  authy
  359  sudo snap remove authy
  360  vi b.cpp
  361  g++ b.cpp -std=c++11
  362  vi b.cpp
  363  g++ b.cpp -std=c++11
  364  vi b.cpp
  365  g++ b.cpp -std=c++11
  366  vi b.cpp
  367  g++ b.cpp -std=c++11
  368  cheese
  369  sudo apt update
  370  sudo apt install apt-transport-https ca-certificates curl gnupg-agent software-properties-common 
  371  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
  372  sudo -i
  373  vi b.cpp
  374  g++ b.cpp -std=c++11
  375  vi b.cpp
  376  g++ b.cpp -std=c++11
  377  vi b.cpp
  378  g++ b.cpp -std=c++11
  379  vi b.cpp
  380  g++ b.cpp -std=c++11
  381  ./a.out
  382  vi b.cpp
  383  g++ b.cpp -std=c++11
  384  ./a.out
  385  vi b.cpp
  386  g++ b.cpp -std=c++11
  387  vi b.cpp
  388  g++ b.cpp -std=c++11
  389  vi b.cpp
  390  g++ b.cpp -std=c++11
  391  ./a.out
  392  vi b.cpp
  393  cheese
  394  cd /usr/share/arduino
  395  cd /user/share/arduino
  396  cd /usr
  397  pwd
  398  ls
  399  cd share
  400  ls
  401  cd /home/nkp
  402  pwd
  403  ls
  404  cd Arduino
  405  ls
  406  cd libraries
  407  ls
  408  vi a.cpp
  409  vi a1.cpp
  410  g++ a1.cpp -std=c++11
  411  vi a1.cpp
  412  g++ a1.cpp -std=c++11
  413  vi a1.cpp
  414  g++ a1.cpp -std=c++11
  415  ./a.out
  416  vi a1.cpp
  417  g++ a1.cpp -std=c++11
  418  ./a.out
  419  vi a1.cpp
  420  g++ a1.cpp -std=c++11
  421  ./a.out
  422  vi a1.cpp
  423  g++ a1.cpp -std=c++11
  424  ./a.out
  425  vi a1.cpp
  426  g++ a1.cpp -std=c++11
  427  vi a1.cpp
  428  g++ a1.cpp -std=c++11
  429  ./a.out
  430  vi a1.cpp
  431  g++ a1.cpp -std=c++11
  432  vi a1.cpp
  433  g++ a1.cpp -std=c++11
  434  vi a1.cpp
  435  g++ a1.cpp -std=c++11
  436  vi a1.cpp
  437  g++ a1.cpp -std=c++11
  438  vi a1.cpp
  439  g++ a1.cpp -std=c++11
  440  ./a.out
  441  vi a1.cpp
  442  g++ a1.cpp -std=c++11
  443  ./a.out
  444  vi a1.cpp
  445  cp a1.cpp  a2.cpp
  446  vi a2.cpp
  447  g++ a2.cpp -std=c++11
  448  vi a2.cpp
  449  g++ a2.cpp -std=c++11
  450  vi a2.cpp
  451  g++ a2.cpp -std=c++11
  452  vi a2.cpp
  453  g++ a2.cpp -std=c++11
  454  ./a.out
  455  vi a2.cpp
  456  g++ a2.cpp -std=c++11
  457  ./a.out
  458  vi a2.cpp
  459  cp a2.cpp a3.cpp
  460  vi a3.cpp
  461  g++ a3.cpp -std=c++11
  462  ./a.out
  463  vi a3.cpp
  464  cp a3.cpp a4.cpp
  465  vi a4.cpp
  466  g++ a4.cpp -std=c++11
  467  vi a4.cpp
  468  g++ a4.cpp -std=c++11
  469  vi a4.cpp
  470  g++ a4.cpp -std=c++11
  471  vi a4.cpp
  472  g++ a4.cpp -std=c++11
  473  vi a4.cpp
  474  g++ a4.cpp -std=c++11
  475  vi a4.cpp
  476  g++ a4.cpp -std=c++11
  477  ./a.out
  478  vi a4.cpp
  479  g++ a4.cpp -std=c++11
  480  ./a.out
  481  vi a4.cpp
  482  g++ a4.cpp -std=c++11
  483  vi a4.cpp
  484  g++ a4.cpp -std=c++11
  485  ./a.out
  486  vi a4.cpp
  487  g++ a4.cpp -std=c++11
  488  vi a4.cpp
  489  vi a3.cpp
  490  cp a3.cpp a31.cpp
  491  vi a31.cpp
  492  g++ a31.cpp -std=c++11
  493  ./a.out
  494  vi a31.cpp
  495  g++ a31.cpp -std=c++11
  496  ./a.out
  497  vi a31.cpp
  498  g++ a31.cpp -std=c++11
  499  ./a.out
  500  vi a31.cpp
  501  vi test.cpp
  502  g++ test.cpp -std=c++11
  503  vi test.cpp
  504  g++ test.cpp -std=c++11
  505  vi test.cpp
  506  g++ test.cpp -std=c++11
  507  vi test.cpp
  508  g++ test.cpp -std=c++11
  509  vi test.cpp
  510  g++ test.cpp -std=c++11
  511  ./a.out
  512  vi test.cpp
  513  g++ test.cpp -std=c++11
  514  ./a.out
  515  vi test.cpp
  516  cp test.cpp test1.cpp
  517  vi test1.cpp
  518  g++ test1.cpp -std=c++11
  519  ./a.out
  520  vi test1.cpp
  521  g++ test1.cpp -std=c++11
  522  ./a.out
  523  vi test1.cpp
  524  g++ test1.cpp -std=c++11
  525  ./a.out
  526  vi test1.cpp
  527  g++ test1.cpp -std=c++11
  528  ./a.out
  529  vi test1.cpp
  530  g++ test1.cpp -std=c++11
  531  ./a.out
  532  vi test1.cpp
  533  g++ test1.cpp -std=c++11
  534  ./a.out
  535  cp test1.cpp test2.cpp
  536  vi test2.cpp
  537  g++ test2.cpp -std=c++11
  538  vi test2.cpp
  539  g++ test2.cpp -std=c++11
  540  vi test2.cpp
  541  g++ test2.cpp -std=c++11
  542  vi test2.cpp
  543  g++ test2.cpp -std=c++11
  544  vi test2.cpp
  545  g++ test2.cpp -std=c++11
  546  vi test2.cpp
  547  g++ test2.cpp -std=c++11
  548  ./a.out
  549  vi test2.cpp
  550  g++ test2.cpp -std=c++11
  551  ./a.out
  552  vi test2.cpp
  553  pwd
  554  ls
  555  vi test2.cpp
  556  vi test1.cpp
  557  git init
  558  git status
  559  git add .
  560  git status
  561  git init
  562  git status
  563  git add .
  564  git status
  565  git commit -m "jajajaj"
  566  git checkout -b nkp_repo
  567  git checkout main
  568  vi test2.cpp
  569  ls *.cpp
  570  ls *.swp
  571  vi test1.cpp
  572  mv .test1.cpp.swp .test1.cpp.swp1
  573  vi test1.cpp
  574  g++ test1.cpp -std=c++11
  575  ./a.out
  576  vi test1.cpp
  577  cp test1.cpp test11.cpp
  578  vi test11.cpp
  579  g++ test11.cpp -std=c++11
  580  ./a.out
  581  vi test11.cpp
  582  vi test2.cpp
  583  g++ test2.cpp -std=c++11
  584  vi test2.cpp
  585  g++ test2.cpp -std=c++11
  586  ./a.out
  587  vi test2.cpp
  588  g++ test2.cpp -std=c++11
  589  cp test2.cpp test21.cpp
  590  vi test21.cpp
  591  g++ test2.cpp -std=c++11
  592  ./a.out
  593  ls
  594  g++ test2.cpp -std=c++11
  595  vi test2.cpp
  596  g++ test21.cpp -std=c++11
  597  ./a.out
  598  g++ test2.cpp -std=c++11
  599  ./a.out
  600  g++ test2.cpp -std=c++11
  601  pwd
  602  g++ test2.cpp -std=c++11
  603  g++ test21.cpp -std=c++11
  604  ./a.out
  605  g++ test21.cpp -std=c++11
  606  ./a.out
  607  vi test21.cpp 
  608  g++ test21.cpp -std=c++11
  609  ./a.out
  610  vi test21.cpp 
  611  g++ test21.cpp -std=c++11
  612  ./a.out
  613  vi test21.cpp 
  614  g++ test21.cpp -std=c++11
  615  ./a.out
  616  vi test21.cpp 
  617  g++ test21.cpp -std=c++11
  618  ./a.out
  619  vi test21.cpp 
  620  g++ test21.cpp -std=c++11
  621  ./a.out
  622  vi test21.cpp 
  623  g++ test21.cpp -std=c++11
  624  ./a.out
  625  vi test21.cpp 
  626  g++ test21.cpp -std=c++11
  627  ./a.out
  628  vi test21.cpp 
  629  g++ test21.cpp -std=c++11
  630  ./a.out
  631  vi test21.cpp 
  632  git status
  633  git add .
  634  git status
  635  git commit -m "will see it"
  636  git config --global user.email nirbhay57@gmail.com
  637  git config --global user.name nirbhay57
  638  git remote add origin https://github.com/nirbhay57/agva.git
  639  git push -u origin main
  640  git remote set-url origin https://github.com/nirbhay57/agva.git
  641  git push -u origin main
  642  git remote -v
  643  git push -u origin main -f
  644  git push -u origin main --force
  645  git branch -M main
  646  git remote add origin https://github.com/nirbhay57/agva.git
  647  git branch -M main
  648  git init 
  649  /home/nkp/realtime_qlabel/8/.git/
  650  rd /home/nkp/realtime_qlabel/8/.git/
  651  rm -r  /home/nkp/realtime_qlabel/8/.git/
  652  rm -rf  /home/nkp/realtime_qlabel/8/.git/
  653  rm -r  /home/nkp/realtime_qlabel/8/.git/
  654  git init
  655  git commit -m "first commit"
  656  git add .
  657  git status
  658  git commit -m "first commit"
  659  git branch -M main
  660  git remote add origin https://github.com/nirbhay57/agva.git
  661  git push -u origin main
  662  curl -u "nirbhay57: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" https://github.com/nirbhay57/agva.git
  663  git push -u origin main
  664  git config --global user.email nirbhay57@gmail.com
  665  git config --global user.name nirbhay57
  666  git config --global user.email nirbhay57@gmail.com
  667  git config -l
  668  git commit -m "first commit"
  669  git add .
  670  git commit -m "first commit"
  671  git status
  672  git add .
  673  git status
  674  git commit -m "first commit"
  675  git branch -M main
  676  git remote add origin https://github.com/nirbhay57/agva.git
  677  git push -u origin main
  678  history
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ history >> hist1.cpp
nkp@nkp-Inspiron-15-3567:~/realtime_qlabel/8$ 

