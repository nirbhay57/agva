#ifndef BTN_H
#define BTN_H

#include <QPushButton>
#include <QWidget>

class btn : public QPushButton
{
public:
	btn();
};

#endif // BTN_H
