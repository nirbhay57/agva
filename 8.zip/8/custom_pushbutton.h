#ifndef CUSTOM_PUSHBUTTON_H
#define CUSTOM_PUSHBUTTON_H

#include <QPushButton>

class custom_pushButton : public QPushButton
{
public:
	custom_pushButton();
};

#endif // CUSTOM_PUSHBUTTON_H
