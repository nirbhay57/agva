#ifndef LABEL_WITH_SLOT_H
#define LABEL_WITH_SLOT_H
#include <QWidget>
#include<QLabel>

class label_with_slot : public QLabel
{
	Q_OBJECT
public:
	label_with_slot();
public slots:

};

#endif // LABEL_WITH_SLOT_H
