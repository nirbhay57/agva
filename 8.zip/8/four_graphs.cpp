#include "four_graphs.h"

four_graphs::four_graphs()
{

}
