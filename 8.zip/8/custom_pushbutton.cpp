#include "custom_pushbutton.h"
#include <QMainWindow>
#include <QPushButton>
#include <QPainter>
#include <iostream>
using namespace std;

custom_pushButton::custom_pushButton()
{
	//Q_OBJECT

//public:
//	button(QWidget *parent = 0)
//		{

//		}
//	~button()
//		{

//		}
//public:
//	void paintEvent(QPaintEvent *p2)
//		{

//		QPushButton::paintEvent(p2);

//			QPainter paint(this);
//			paint.save();
//			QFont sub(QApplication::font());
//			sub.setPointSize(sub.pointSize() + 7);
//			paint.setFont(sub);
//			paint.drawText(QPoint(300,300),"Hi");
//			paint.restore();

//		}
	//cout<<"abc";


}
