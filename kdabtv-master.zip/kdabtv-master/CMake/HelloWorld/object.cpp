#include "object.h"

// Dummy class, just to have one more cpp file in the CMakeLists.txt

My::My() : QObject() {}

