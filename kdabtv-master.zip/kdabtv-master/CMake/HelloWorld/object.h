#pragma once
#include <QObject>

// Dummy class, just to have one more cpp file in the CMakeLists.txt

class My : public QObject
{
public:
    My();
};
