# Qt Widget and More

Welcome to the Qt Widgets and More source archive, here you may find source code for each episode.

Here is a [playlist for all episodes](https://www.youtube.com/playlist?list=PL6CJYn40gN6gf-G-o6syFwGrtq3kItEqI)

Some of the episodes guide you to set up Qt Creator or Linux. In case your changes are lost during an upgrade, here are 
quick re-setup guides for [Qt Creator](Docs/QtCreator-setup.md) and [Linux](Docs/Linux-setup.md). 
