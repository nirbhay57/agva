#pragma once

class VariablesAndExpressions
{
public:
    void test();
    void test2();
};
