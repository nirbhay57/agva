extern void part1();
extern void part2();
extern void part3();
extern void part4();

int main()
{
    (void)part4();
    return 0;
}
