#include <iostream>
#include "message.h"
using namespace std;

void message::printMessage(){
	cout << "Makefile Example\n";
}
