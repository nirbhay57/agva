#include "message.h"
//#include <cstdlib.h>
using namespace std;
int main(){
message m;
m.printMessage();

return 0;
}
